package com.example.workwise_prototype

data class CourseResponse(
    val course_url: String
)
