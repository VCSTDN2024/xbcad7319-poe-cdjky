package com.example.workwise_prototype  // Adjust to match your actual package name

data class AppUser(
    val fullName: String,
    val email: String
)
//